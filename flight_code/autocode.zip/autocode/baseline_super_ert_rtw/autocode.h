//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: autocode.h
//
// Code generated for Simulink model 'baseline_super'.
//
// Model version                  : 2.201
// Simulink Coder version         : 9.5 (R2021a) 14-Nov-2020
// C/C++ source code generated on : Mon Nov  1 16:44:10 2021
//
// Target selection: ert.tlc
// Embedded hardware selection: NXP->Cortex-M4
// Code generation objective: Execution efficiency
// Validation result: Not run
//
#ifndef RTW_HEADER_autocode_h_
#define RTW_HEADER_autocode_h_
#include "rtwtypes.h"
#include <stddef.h>
#include <cmath>
#include <cstring>
#include <array>
#include "flight/global_defs.h"
#include "rtwtypes.h"

// Model Code Variants

// Macros for accessing real-time model data structure
#ifndef DEFINED_TYPEDEF_FOR_struct_KfVHRj0wYibL5bQnTxAZMH_
#define DEFINED_TYPEDEF_FOR_struct_KfVHRj0wYibL5bQnTxAZMH_

struct struct_KfVHRj0wYibL5bQnTxAZMH
{
  real32_T throttle;
  real32_T roll_cc;
  real32_T pitch_cc;
  real32_T yaw_cc;
};

#endif

extern "C" {
  static real_T rtGetInf(void);
  static real32_T rtGetInfF(void);
  static real_T rtGetMinusInf(void);
  static real32_T rtGetMinusInfF(void);
}                                      // extern "C"
  extern "C"
{
  static real_T rtGetNaN(void);
  static real32_T rtGetNaNF(void);
}                                      // extern "C"

extern "C" {
  extern real_T rtInf;
  extern real_T rtMinusInf;
  extern real_T rtNaN;
  extern real32_T rtInfF;
  extern real32_T rtMinusInfF;
  extern real32_T rtNaNF;
  static void rt_InitInfAndNaN(size_t realSize);
  static boolean_T rtIsInf(real_T value);
  static boolean_T rtIsInfF(real32_T value);
  static boolean_T rtIsNaN(real_T value);
  static boolean_T rtIsNaNF(real32_T value);
  struct BigEndianIEEEDouble {
    struct {
      uint32_T wordH;
      uint32_T wordL;
    } words;
  };

  struct LittleEndianIEEEDouble {
    struct {
      uint32_T wordL;
      uint32_T wordH;
    } words;
  };

  struct IEEESingle {
    union {
      real32_T wordLreal;
      uint32_T wordLuint;
    } wordL;
  };
}                                      // extern "C"
  // Class declaration for model baseline_super
  namespace bfs
{
  class Autocode {
    // public data and function members
   public:
    // Block signals and states (default storage) for system '<Root>'
    struct DW {
      real32_T throttle;
                    // '<S5>/BusConversion_InsertedFor_Command out_at_inport_0'
      real32_T Saturation;             // '<S384>/Saturation'
      real32_T roll_angle_error;       // '<S339>/Sum'
      real32_T Saturation_i;           // '<S437>/Saturation'
      real32_T Saturation_d;           // '<S490>/Saturation'
      real32_T Saturation_f;           // '<S111>/Saturation'
      real32_T Saturation_j;           // '<S58>/Saturation'
      real32_T Saturation_a;           // '<S8>/Saturation'
      real32_T Saturation_h;           // '<S326>/Saturation'
      real32_T UD_DSTATE;              // '<S370>/UD'
      real32_T Integrator_DSTATE;      // '<S377>/Integrator'
      real32_T UD_DSTATE_d;            // '<S423>/UD'
      real32_T Integrator_DSTATE_g;    // '<S430>/Integrator'
      real32_T UD_DSTATE_l;            // '<S476>/UD'
      real32_T Integrator_DSTATE_f;    // '<S483>/Integrator'
      real32_T Integrator_DSTATE_m;    // '<S210>/Integrator'
      real32_T UD_DSTATE_m;            // '<S203>/UD'
      real32_T Integrator_DSTATE_a;    // '<S104>/Integrator'
      real32_T UD_DSTATE_lt;           // '<S97>/UD'
      real32_T Integrator_DSTATE_p;    // '<S157>/Integrator'
      real32_T UD_DSTATE_n;            // '<S150>/UD'
      real32_T Integrator_DSTATE_p5;   // '<S51>/Integrator'
      real32_T UD_DSTATE_p;            // '<S44>/UD'
      real32_T Integrator_DSTATE_h;    // '<S264>/Integrator'
      real32_T UD_DSTATE_ms;           // '<S257>/UD'
      real32_T UD_DSTATE_pt;           // '<S312>/UD'
      real32_T Integrator_DSTATE_d;    // '<S319>/Integrator'
    };

    // Invariant block signals (default storage)
    struct ConstB {
      std::array<real32_T, 32> Transpose;// '<S3>/Transpose'
    };

    // model initialize function
    void initialize();

    // model step function
    void Run(const SysData &sys, const SensorData &sensor, const NavData &nav,
             const TelemData &telem, ControlData *ctrl);

    // Constructor
    Autocode();

    // Destructor
    ~Autocode();

    // private data and function members
   private:
    // Block signals and states
    DW rtDW;
  };
}

extern const bfs::Autocode::ConstB rtConstB;// constant block i/o

//-
//  These blocks were eliminated from the model due to optimizations:
//
//  Block '<S44>/DTDup' : Unused code path elimination
//  Block '<S97>/DTDup' : Unused code path elimination
//  Block '<S7>/Scope' : Unused code path elimination
//  Block '<S7>/Scope1' : Unused code path elimination
//  Block '<S7>/Scope2' : Unused code path elimination
//  Block '<S7>/Scope3' : Unused code path elimination
//  Block '<S7>/Scope4' : Unused code path elimination
//  Block '<S7>/Scope5' : Unused code path elimination
//  Block '<S150>/DTDup' : Unused code path elimination
//  Block '<S13>/Scope' : Unused code path elimination
//  Block '<S13>/Scope1' : Unused code path elimination
//  Block '<S203>/DTDup' : Unused code path elimination
//  Block '<S257>/DTDup' : Unused code path elimination
//  Block '<S312>/DTDup' : Unused code path elimination
//  Block '<S370>/DTDup' : Unused code path elimination
//  Block '<S338>/Scope' : Unused code path elimination
//  Block '<S423>/DTDup' : Unused code path elimination
//  Block '<S339>/Scope' : Unused code path elimination
//  Block '<S476>/DTDup' : Unused code path elimination
//  Block '<S6>/mode1' : Unused code path elimination
//  Block '<S6>/mode2' : Unused code path elimination
//  Block '<S6>/mode3' : Unused code path elimination
//  Block '<S6>/mode4' : Unused code path elimination
//  Block '<Root>/Data Type Conversion1' : Eliminate redundant data type conversion
//  Block '<S7>/Gain' : Eliminated nontunable gain of 1
//  Block '<S7>/Gain1' : Eliminated nontunable gain of 1
//  Block '<S164>/Saturation' : Eliminated Saturate block
//  Block '<S217>/Saturation' : Eliminated Saturate block
//  Block '<S271>/Saturation' : Eliminated Saturate block
//  Block '<S501>/Data Type Conversion' : Eliminate redundant data type conversion
//  Block '<S501>/Data Type Conversion1' : Eliminate redundant data type conversion


//-
//  The generated code includes comments that allow you to trace directly
//  back to the appropriate location in the model.  The basic format
//  is <system>/block_name, where system is the system number (uniquely
//  assigned by Simulink) and block_name is the name of the block.
//
//  Use the MATLAB hilite_system command to trace the generated code back
//  to the model.  For example,
//
//  hilite_system('<S3>')    - opens system 3
//  hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
//
//  Here is the system hierarchy for this model
//
//  '<Root>' : 'baseline_super'
//  '<S1>'   : 'baseline_super/Compare To Constant1'
//  '<S2>'   : 'baseline_super/Compare To Constant2'
//  '<S3>'   : 'baseline_super/Motor Mixing Algorithm'
//  '<S4>'   : 'baseline_super/POS_HOLD CONTROLLER'
//  '<S5>'   : 'baseline_super/STABILIZED CONTROLER'
//  '<S6>'   : 'baseline_super/To Control Data'
//  '<S7>'   : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller'
//  '<S8>'   : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller'
//  '<S9>'   : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller'
//  '<S10>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/2D rotation from NED_xy to body_xy'
//  '<S11>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller'
//  '<S12>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller'
//  '<S13>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem'
//  '<S14>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1'
//  '<S15>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller'
//  '<S16>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Anti-windup'
//  '<S17>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/D Gain'
//  '<S18>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Filter'
//  '<S19>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Filter ICs'
//  '<S20>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/I Gain'
//  '<S21>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Ideal P Gain'
//  '<S22>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Ideal P Gain Fdbk'
//  '<S23>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Integrator'
//  '<S24>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Integrator ICs'
//  '<S25>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/N Copy'
//  '<S26>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/N Gain'
//  '<S27>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/P Copy'
//  '<S28>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Parallel P Gain'
//  '<S29>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Reset Signal'
//  '<S30>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Saturation'
//  '<S31>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Saturation Fdbk'
//  '<S32>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Sum'
//  '<S33>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Sum Fdbk'
//  '<S34>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Tracking Mode'
//  '<S35>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Tracking Mode Sum'
//  '<S36>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Tsamp - Integral'
//  '<S37>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Tsamp - Ngain'
//  '<S38>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/postSat Signal'
//  '<S39>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/preSat Signal'
//  '<S40>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Anti-windup/Disc. Clamping Parallel'
//  '<S41>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Anti-windup/Disc. Clamping Parallel/Dead Zone'
//  '<S42>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Anti-windup/Disc. Clamping Parallel/Dead Zone/Enabled'
//  '<S43>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/D Gain/External Parameters'
//  '<S44>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Filter/Differentiator'
//  '<S45>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Filter/Differentiator/Tsamp'
//  '<S46>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Filter/Differentiator/Tsamp/Internal Ts'
//  '<S47>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Filter ICs/Internal IC - Differentiator'
//  '<S48>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/I Gain/External Parameters'
//  '<S49>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Ideal P Gain/Passthrough'
//  '<S50>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Ideal P Gain Fdbk/Disabled'
//  '<S51>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Integrator/Discrete'
//  '<S52>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Integrator ICs/Internal IC'
//  '<S53>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/N Copy/Disabled wSignal Specification'
//  '<S54>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/N Gain/Passthrough'
//  '<S55>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/P Copy/Disabled'
//  '<S56>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Parallel P Gain/External Parameters'
//  '<S57>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Reset Signal/Disabled'
//  '<S58>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Saturation/Enabled'
//  '<S59>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Saturation Fdbk/Disabled'
//  '<S60>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Sum/Sum_PID'
//  '<S61>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Sum Fdbk/Disabled'
//  '<S62>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Tracking Mode/Disabled'
//  '<S63>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Tracking Mode Sum/Passthrough'
//  '<S64>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Tsamp - Integral/Passthrough'
//  '<S65>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/Tsamp - Ngain/Passthrough'
//  '<S66>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/postSat Signal/Forward_Path'
//  '<S67>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Pitch Controller/Pitch angle controller/preSat Signal/Forward_Path'
//  '<S68>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1'
//  '<S69>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Anti-windup'
//  '<S70>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/D Gain'
//  '<S71>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Filter'
//  '<S72>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Filter ICs'
//  '<S73>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/I Gain'
//  '<S74>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Ideal P Gain'
//  '<S75>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Ideal P Gain Fdbk'
//  '<S76>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Integrator'
//  '<S77>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Integrator ICs'
//  '<S78>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/N Copy'
//  '<S79>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/N Gain'
//  '<S80>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/P Copy'
//  '<S81>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Parallel P Gain'
//  '<S82>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Reset Signal'
//  '<S83>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Saturation'
//  '<S84>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Saturation Fdbk'
//  '<S85>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Sum'
//  '<S86>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Sum Fdbk'
//  '<S87>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Tracking Mode'
//  '<S88>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Tracking Mode Sum'
//  '<S89>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Tsamp - Integral'
//  '<S90>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Tsamp - Ngain'
//  '<S91>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/postSat Signal'
//  '<S92>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/preSat Signal'
//  '<S93>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Anti-windup/Disc. Clamping Parallel'
//  '<S94>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Anti-windup/Disc. Clamping Parallel/Dead Zone'
//  '<S95>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Anti-windup/Disc. Clamping Parallel/Dead Zone/Enabled'
//  '<S96>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/D Gain/External Parameters'
//  '<S97>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Filter/Differentiator'
//  '<S98>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Filter/Differentiator/Tsamp'
//  '<S99>'  : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Filter/Differentiator/Tsamp/Internal Ts'
//  '<S100>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Filter ICs/Internal IC - Differentiator'
//  '<S101>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/I Gain/External Parameters'
//  '<S102>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Ideal P Gain/Passthrough'
//  '<S103>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Ideal P Gain Fdbk/Disabled'
//  '<S104>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Integrator/Discrete'
//  '<S105>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Integrator ICs/Internal IC'
//  '<S106>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/N Copy/Disabled wSignal Specification'
//  '<S107>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/N Gain/Passthrough'
//  '<S108>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/P Copy/Disabled'
//  '<S109>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Parallel P Gain/External Parameters'
//  '<S110>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Reset Signal/Disabled'
//  '<S111>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Saturation/Enabled'
//  '<S112>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Saturation Fdbk/Disabled'
//  '<S113>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Sum/Sum_PID'
//  '<S114>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Sum Fdbk/Disabled'
//  '<S115>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Tracking Mode/Disabled'
//  '<S116>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Tracking Mode Sum/Passthrough'
//  '<S117>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Tsamp - Integral/Passthrough'
//  '<S118>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/Tsamp - Ngain/Passthrough'
//  '<S119>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/postSat Signal/Forward_Path'
//  '<S120>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Roll Controller/PID Controller1/preSat Signal/Forward_Path'
//  '<S121>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller'
//  '<S122>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Anti-windup'
//  '<S123>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/D Gain'
//  '<S124>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Filter'
//  '<S125>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Filter ICs'
//  '<S126>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/I Gain'
//  '<S127>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Ideal P Gain'
//  '<S128>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Ideal P Gain Fdbk'
//  '<S129>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Integrator'
//  '<S130>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Integrator ICs'
//  '<S131>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/N Copy'
//  '<S132>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/N Gain'
//  '<S133>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/P Copy'
//  '<S134>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Parallel P Gain'
//  '<S135>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Reset Signal'
//  '<S136>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Saturation'
//  '<S137>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Saturation Fdbk'
//  '<S138>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Sum'
//  '<S139>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Sum Fdbk'
//  '<S140>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Tracking Mode'
//  '<S141>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Tracking Mode Sum'
//  '<S142>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Tsamp - Integral'
//  '<S143>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Tsamp - Ngain'
//  '<S144>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/postSat Signal'
//  '<S145>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/preSat Signal'
//  '<S146>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Anti-windup/Disc. Clamping Parallel'
//  '<S147>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Anti-windup/Disc. Clamping Parallel/Dead Zone'
//  '<S148>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Anti-windup/Disc. Clamping Parallel/Dead Zone/Enabled'
//  '<S149>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/D Gain/External Parameters'
//  '<S150>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Filter/Differentiator'
//  '<S151>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Filter/Differentiator/Tsamp'
//  '<S152>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Filter/Differentiator/Tsamp/Internal Ts'
//  '<S153>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Filter ICs/Internal IC - Differentiator'
//  '<S154>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/I Gain/External Parameters'
//  '<S155>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Ideal P Gain/Passthrough'
//  '<S156>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Ideal P Gain Fdbk/Disabled'
//  '<S157>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Integrator/Discrete'
//  '<S158>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Integrator ICs/Internal IC'
//  '<S159>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/N Copy/Disabled wSignal Specification'
//  '<S160>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/N Gain/Passthrough'
//  '<S161>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/P Copy/Disabled'
//  '<S162>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Parallel P Gain/External Parameters'
//  '<S163>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Reset Signal/Disabled'
//  '<S164>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Saturation/Enabled'
//  '<S165>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Saturation Fdbk/Disabled'
//  '<S166>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Sum/Sum_PID'
//  '<S167>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Sum Fdbk/Disabled'
//  '<S168>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Tracking Mode/Disabled'
//  '<S169>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Tracking Mode Sum/Passthrough'
//  '<S170>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Tsamp - Integral/Passthrough'
//  '<S171>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/Tsamp - Ngain/Passthrough'
//  '<S172>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/postSat Signal/Forward_Path'
//  '<S173>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem/Pitch angle controller/preSat Signal/Forward_Path'
//  '<S174>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller'
//  '<S175>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Anti-windup'
//  '<S176>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/D Gain'
//  '<S177>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Filter'
//  '<S178>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Filter ICs'
//  '<S179>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/I Gain'
//  '<S180>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Ideal P Gain'
//  '<S181>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Ideal P Gain Fdbk'
//  '<S182>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Integrator'
//  '<S183>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Integrator ICs'
//  '<S184>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/N Copy'
//  '<S185>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/N Gain'
//  '<S186>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/P Copy'
//  '<S187>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Parallel P Gain'
//  '<S188>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Reset Signal'
//  '<S189>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Saturation'
//  '<S190>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Saturation Fdbk'
//  '<S191>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Sum'
//  '<S192>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Sum Fdbk'
//  '<S193>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Tracking Mode'
//  '<S194>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Tracking Mode Sum'
//  '<S195>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Tsamp - Integral'
//  '<S196>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Tsamp - Ngain'
//  '<S197>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/postSat Signal'
//  '<S198>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/preSat Signal'
//  '<S199>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Anti-windup/Disc. Clamping Parallel'
//  '<S200>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Anti-windup/Disc. Clamping Parallel/Dead Zone'
//  '<S201>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Anti-windup/Disc. Clamping Parallel/Dead Zone/Enabled'
//  '<S202>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/D Gain/External Parameters'
//  '<S203>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Filter/Differentiator'
//  '<S204>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Filter/Differentiator/Tsamp'
//  '<S205>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Filter/Differentiator/Tsamp/Internal Ts'
//  '<S206>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Filter ICs/Internal IC - Differentiator'
//  '<S207>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/I Gain/External Parameters'
//  '<S208>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Ideal P Gain/Passthrough'
//  '<S209>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Ideal P Gain Fdbk/Disabled'
//  '<S210>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Integrator/Discrete'
//  '<S211>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Integrator ICs/Internal IC'
//  '<S212>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/N Copy/Disabled wSignal Specification'
//  '<S213>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/N Gain/Passthrough'
//  '<S214>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/P Copy/Disabled'
//  '<S215>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Parallel P Gain/External Parameters'
//  '<S216>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Reset Signal/Disabled'
//  '<S217>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Saturation/Enabled'
//  '<S218>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Saturation Fdbk/Disabled'
//  '<S219>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Sum/Sum_PID'
//  '<S220>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Sum Fdbk/Disabled'
//  '<S221>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Tracking Mode/Disabled'
//  '<S222>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Tracking Mode Sum/Passthrough'
//  '<S223>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Tsamp - Integral/Passthrough'
//  '<S224>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/Tsamp - Ngain/Passthrough'
//  '<S225>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/postSat Signal/Forward_Path'
//  '<S226>' : 'baseline_super/POS_HOLD CONTROLLER/Horizontal speed controller/Subsystem1/Roll angle controller/preSat Signal/Forward_Path'
//  '<S227>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller'
//  '<S228>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/Throttle Mapper'
//  '<S229>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Anti-windup'
//  '<S230>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/D Gain'
//  '<S231>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Filter'
//  '<S232>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Filter ICs'
//  '<S233>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/I Gain'
//  '<S234>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Ideal P Gain'
//  '<S235>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Ideal P Gain Fdbk'
//  '<S236>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Integrator'
//  '<S237>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Integrator ICs'
//  '<S238>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/N Copy'
//  '<S239>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/N Gain'
//  '<S240>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/P Copy'
//  '<S241>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Parallel P Gain'
//  '<S242>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Reset Signal'
//  '<S243>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Saturation'
//  '<S244>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Saturation Fdbk'
//  '<S245>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Sum'
//  '<S246>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Sum Fdbk'
//  '<S247>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Tracking Mode'
//  '<S248>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Tracking Mode Sum'
//  '<S249>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Tsamp - Integral'
//  '<S250>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Tsamp - Ngain'
//  '<S251>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/postSat Signal'
//  '<S252>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/preSat Signal'
//  '<S253>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Anti-windup/Disc. Clamping Parallel'
//  '<S254>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Anti-windup/Disc. Clamping Parallel/Dead Zone'
//  '<S255>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Anti-windup/Disc. Clamping Parallel/Dead Zone/Enabled'
//  '<S256>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/D Gain/External Parameters'
//  '<S257>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Filter/Differentiator'
//  '<S258>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Filter/Differentiator/Tsamp'
//  '<S259>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Filter/Differentiator/Tsamp/Internal Ts'
//  '<S260>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Filter ICs/Internal IC - Differentiator'
//  '<S261>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/I Gain/External Parameters'
//  '<S262>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Ideal P Gain/Passthrough'
//  '<S263>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Ideal P Gain Fdbk/Disabled'
//  '<S264>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Integrator/Discrete'
//  '<S265>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Integrator ICs/Internal IC'
//  '<S266>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/N Copy/Disabled wSignal Specification'
//  '<S267>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/N Gain/Passthrough'
//  '<S268>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/P Copy/Disabled'
//  '<S269>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Parallel P Gain/External Parameters'
//  '<S270>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Reset Signal/Disabled'
//  '<S271>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Saturation/Enabled'
//  '<S272>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Saturation Fdbk/Disabled'
//  '<S273>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Sum/Sum_PID'
//  '<S274>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Sum Fdbk/Disabled'
//  '<S275>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Tracking Mode/Disabled'
//  '<S276>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Tracking Mode Sum/Passthrough'
//  '<S277>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Tsamp - Integral/Passthrough'
//  '<S278>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/Tsamp - Ngain/Passthrough'
//  '<S279>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/postSat Signal/Forward_Path'
//  '<S280>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/PID Controller/preSat Signal/Forward_Path'
//  '<S281>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/Throttle Mapper/Compare To Constant'
//  '<S282>' : 'baseline_super/POS_HOLD CONTROLLER/Vertical speed controller/Throttle Mapper/Compare To Constant1'
//  '<S283>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller'
//  '<S284>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Anti-windup'
//  '<S285>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/D Gain'
//  '<S286>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Filter'
//  '<S287>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Filter ICs'
//  '<S288>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/I Gain'
//  '<S289>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Ideal P Gain'
//  '<S290>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Ideal P Gain Fdbk'
//  '<S291>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Integrator'
//  '<S292>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Integrator ICs'
//  '<S293>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/N Copy'
//  '<S294>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/N Gain'
//  '<S295>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/P Copy'
//  '<S296>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Parallel P Gain'
//  '<S297>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Reset Signal'
//  '<S298>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Saturation'
//  '<S299>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Saturation Fdbk'
//  '<S300>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Sum'
//  '<S301>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Sum Fdbk'
//  '<S302>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Tracking Mode'
//  '<S303>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Tracking Mode Sum'
//  '<S304>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Tsamp - Integral'
//  '<S305>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Tsamp - Ngain'
//  '<S306>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/postSat Signal'
//  '<S307>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/preSat Signal'
//  '<S308>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Anti-windup/Disc. Clamping Parallel'
//  '<S309>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Anti-windup/Disc. Clamping Parallel/Dead Zone'
//  '<S310>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Anti-windup/Disc. Clamping Parallel/Dead Zone/Enabled'
//  '<S311>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/D Gain/External Parameters'
//  '<S312>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Filter/Differentiator'
//  '<S313>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Filter/Differentiator/Tsamp'
//  '<S314>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Filter/Differentiator/Tsamp/Internal Ts'
//  '<S315>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Filter ICs/Internal IC - Differentiator'
//  '<S316>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/I Gain/External Parameters'
//  '<S317>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Ideal P Gain/Passthrough'
//  '<S318>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Ideal P Gain Fdbk/Disabled'
//  '<S319>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Integrator/Discrete'
//  '<S320>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Integrator ICs/Internal IC'
//  '<S321>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/N Copy/Disabled wSignal Specification'
//  '<S322>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/N Gain/Passthrough'
//  '<S323>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/P Copy/Disabled'
//  '<S324>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Parallel P Gain/External Parameters'
//  '<S325>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Reset Signal/Disabled'
//  '<S326>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Saturation/Enabled'
//  '<S327>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Saturation Fdbk/Disabled'
//  '<S328>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Sum/Sum_PID'
//  '<S329>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Sum Fdbk/Disabled'
//  '<S330>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Tracking Mode/Disabled'
//  '<S331>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Tracking Mode Sum/Passthrough'
//  '<S332>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Tsamp - Integral/Passthrough'
//  '<S333>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/Tsamp - Ngain/Passthrough'
//  '<S334>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/postSat Signal/Forward_Path'
//  '<S335>' : 'baseline_super/POS_HOLD CONTROLLER/Yaw Rate Controller/PID Controller/preSat Signal/Forward_Path'
//  '<S336>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control'
//  '<S337>' : 'baseline_super/STABILIZED CONTROLER/Outer Loop Control'
//  '<S338>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller'
//  '<S339>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller'
//  '<S340>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller'
//  '<S341>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller'
//  '<S342>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Anti-windup'
//  '<S343>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/D Gain'
//  '<S344>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Filter'
//  '<S345>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Filter ICs'
//  '<S346>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/I Gain'
//  '<S347>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Ideal P Gain'
//  '<S348>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Ideal P Gain Fdbk'
//  '<S349>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Integrator'
//  '<S350>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Integrator ICs'
//  '<S351>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/N Copy'
//  '<S352>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/N Gain'
//  '<S353>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/P Copy'
//  '<S354>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Parallel P Gain'
//  '<S355>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Reset Signal'
//  '<S356>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Saturation'
//  '<S357>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Saturation Fdbk'
//  '<S358>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Sum'
//  '<S359>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Sum Fdbk'
//  '<S360>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Tracking Mode'
//  '<S361>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Tracking Mode Sum'
//  '<S362>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Tsamp - Integral'
//  '<S363>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Tsamp - Ngain'
//  '<S364>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/postSat Signal'
//  '<S365>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/preSat Signal'
//  '<S366>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Anti-windup/Disc. Clamping Parallel'
//  '<S367>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Anti-windup/Disc. Clamping Parallel/Dead Zone'
//  '<S368>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Anti-windup/Disc. Clamping Parallel/Dead Zone/Enabled'
//  '<S369>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/D Gain/External Parameters'
//  '<S370>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Filter/Differentiator'
//  '<S371>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Filter/Differentiator/Tsamp'
//  '<S372>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Filter/Differentiator/Tsamp/Internal Ts'
//  '<S373>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Filter ICs/Internal IC - Differentiator'
//  '<S374>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/I Gain/External Parameters'
//  '<S375>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Ideal P Gain/Passthrough'
//  '<S376>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Ideal P Gain Fdbk/Disabled'
//  '<S377>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Integrator/Discrete'
//  '<S378>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Integrator ICs/Internal IC'
//  '<S379>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/N Copy/Disabled wSignal Specification'
//  '<S380>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/N Gain/Passthrough'
//  '<S381>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/P Copy/Disabled'
//  '<S382>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Parallel P Gain/External Parameters'
//  '<S383>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Reset Signal/Disabled'
//  '<S384>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Saturation/Enabled'
//  '<S385>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Saturation Fdbk/Disabled'
//  '<S386>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Sum/Sum_PID'
//  '<S387>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Sum Fdbk/Disabled'
//  '<S388>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Tracking Mode/Disabled'
//  '<S389>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Tracking Mode Sum/Passthrough'
//  '<S390>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Tsamp - Integral/Passthrough'
//  '<S391>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/Tsamp - Ngain/Passthrough'
//  '<S392>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/postSat Signal/Forward_Path'
//  '<S393>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Pitch Controller/Pitch angle controller/preSat Signal/Forward_Path'
//  '<S394>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1'
//  '<S395>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Anti-windup'
//  '<S396>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/D Gain'
//  '<S397>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Filter'
//  '<S398>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Filter ICs'
//  '<S399>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/I Gain'
//  '<S400>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Ideal P Gain'
//  '<S401>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Ideal P Gain Fdbk'
//  '<S402>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Integrator'
//  '<S403>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Integrator ICs'
//  '<S404>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/N Copy'
//  '<S405>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/N Gain'
//  '<S406>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/P Copy'
//  '<S407>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Parallel P Gain'
//  '<S408>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Reset Signal'
//  '<S409>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Saturation'
//  '<S410>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Saturation Fdbk'
//  '<S411>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Sum'
//  '<S412>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Sum Fdbk'
//  '<S413>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Tracking Mode'
//  '<S414>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Tracking Mode Sum'
//  '<S415>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Tsamp - Integral'
//  '<S416>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Tsamp - Ngain'
//  '<S417>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/postSat Signal'
//  '<S418>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/preSat Signal'
//  '<S419>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Anti-windup/Disc. Clamping Parallel'
//  '<S420>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Anti-windup/Disc. Clamping Parallel/Dead Zone'
//  '<S421>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Anti-windup/Disc. Clamping Parallel/Dead Zone/Enabled'
//  '<S422>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/D Gain/External Parameters'
//  '<S423>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Filter/Differentiator'
//  '<S424>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Filter/Differentiator/Tsamp'
//  '<S425>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Filter/Differentiator/Tsamp/Internal Ts'
//  '<S426>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Filter ICs/Internal IC - Differentiator'
//  '<S427>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/I Gain/External Parameters'
//  '<S428>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Ideal P Gain/Passthrough'
//  '<S429>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Ideal P Gain Fdbk/Disabled'
//  '<S430>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Integrator/Discrete'
//  '<S431>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Integrator ICs/Internal IC'
//  '<S432>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/N Copy/Disabled wSignal Specification'
//  '<S433>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/N Gain/Passthrough'
//  '<S434>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/P Copy/Disabled'
//  '<S435>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Parallel P Gain/External Parameters'
//  '<S436>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Reset Signal/Disabled'
//  '<S437>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Saturation/Enabled'
//  '<S438>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Saturation Fdbk/Disabled'
//  '<S439>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Sum/Sum_PID'
//  '<S440>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Sum Fdbk/Disabled'
//  '<S441>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Tracking Mode/Disabled'
//  '<S442>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Tracking Mode Sum/Passthrough'
//  '<S443>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Tsamp - Integral/Passthrough'
//  '<S444>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/Tsamp - Ngain/Passthrough'
//  '<S445>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/postSat Signal/Forward_Path'
//  '<S446>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Roll Controller/PID Controller1/preSat Signal/Forward_Path'
//  '<S447>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller'
//  '<S448>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Anti-windup'
//  '<S449>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/D Gain'
//  '<S450>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Filter'
//  '<S451>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Filter ICs'
//  '<S452>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/I Gain'
//  '<S453>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Ideal P Gain'
//  '<S454>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Ideal P Gain Fdbk'
//  '<S455>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Integrator'
//  '<S456>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Integrator ICs'
//  '<S457>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/N Copy'
//  '<S458>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/N Gain'
//  '<S459>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/P Copy'
//  '<S460>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Parallel P Gain'
//  '<S461>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Reset Signal'
//  '<S462>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Saturation'
//  '<S463>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Saturation Fdbk'
//  '<S464>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Sum'
//  '<S465>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Sum Fdbk'
//  '<S466>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Tracking Mode'
//  '<S467>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Tracking Mode Sum'
//  '<S468>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Tsamp - Integral'
//  '<S469>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Tsamp - Ngain'
//  '<S470>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/postSat Signal'
//  '<S471>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/preSat Signal'
//  '<S472>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Anti-windup/Disc. Clamping Parallel'
//  '<S473>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Anti-windup/Disc. Clamping Parallel/Dead Zone'
//  '<S474>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Anti-windup/Disc. Clamping Parallel/Dead Zone/Enabled'
//  '<S475>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/D Gain/External Parameters'
//  '<S476>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Filter/Differentiator'
//  '<S477>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Filter/Differentiator/Tsamp'
//  '<S478>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Filter/Differentiator/Tsamp/Internal Ts'
//  '<S479>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Filter ICs/Internal IC - Differentiator'
//  '<S480>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/I Gain/External Parameters'
//  '<S481>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Ideal P Gain/Passthrough'
//  '<S482>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Ideal P Gain Fdbk/Disabled'
//  '<S483>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Integrator/Discrete'
//  '<S484>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Integrator ICs/Internal IC'
//  '<S485>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/N Copy/Disabled wSignal Specification'
//  '<S486>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/N Gain/Passthrough'
//  '<S487>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/P Copy/Disabled'
//  '<S488>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Parallel P Gain/External Parameters'
//  '<S489>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Reset Signal/Disabled'
//  '<S490>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Saturation/Enabled'
//  '<S491>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Saturation Fdbk/Disabled'
//  '<S492>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Sum/Sum_PID'
//  '<S493>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Sum Fdbk/Disabled'
//  '<S494>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Tracking Mode/Disabled'
//  '<S495>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Tracking Mode Sum/Passthrough'
//  '<S496>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Tsamp - Integral/Passthrough'
//  '<S497>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/Tsamp - Ngain/Passthrough'
//  '<S498>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/postSat Signal/Forward_Path'
//  '<S499>' : 'baseline_super/STABILIZED CONTROLER/Inner Loop Control/Yaw Rate Controller/PID Controller/preSat Signal/Forward_Path'
//  '<S500>' : 'baseline_super/STABILIZED CONTROLER/Outer Loop Control/Manual Controller'
//  '<S501>' : 'baseline_super/To Control Data/SBUS & AUX1'

#endif                                 // RTW_HEADER_autocode_h_

//
// File trailer for generated code.
//
// [EOF]
//
