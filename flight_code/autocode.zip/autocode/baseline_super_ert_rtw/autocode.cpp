//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: autocode.cpp
//
// Code generated for Simulink model 'baseline_super'.
//
// Model version                  : 2.203
// Simulink Coder version         : 9.5 (R2021a) 14-Nov-2020
// C/C++ source code generated on : Thu Nov  4 15:40:23 2021
//
// Target selection: ert.tlc
// Embedded hardware selection: NXP->Cortex-M4
// Code generation objective: Execution efficiency
// Validation result: Not run
//

#include <array>
#include "autocode.h"
#define NumBitsPerChar                 8U
#ifndef UCHAR_MAX
#include <limits.h>
#endif

#if ( UCHAR_MAX != (0xFFU) ) || ( SCHAR_MAX != (0x7F) )
#error Code was generated for compiler with different sized uchar/char. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( USHRT_MAX != (0xFFFFU) ) || ( SHRT_MAX != (0x7FFF) )
#error Code was generated for compiler with different sized ushort/short. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( UINT_MAX != (0xFFFFFFFFU) ) || ( INT_MAX != (0x7FFFFFFF) )
#error Code was generated for compiler with different sized uint/int. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( ULONG_MAX != (0xFFFFFFFFU) ) || ( LONG_MAX != (0x7FFFFFFF) )
#error Code was generated for compiler with different sized ulong/long. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

// Skipping ulong_long/long_long check: insufficient preprocessor integer range.

// Invariant block signals (default storage)
const bfs::Autocode::ConstB rtConstB = {
  { {
      0.8F,
      -0.2F,
      0.2F,
      0.2F,
      0.8F,
      0.2F,
      -0.2F,
      0.2F,
      0.8F,
      0.2F,
      0.2F,
      -0.2F,
      0.8F,
      -0.2F,
      -0.2F,
      -0.2F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F
    }
  }                                    // '<S3>/Transpose'
};

extern "C" {
  real_T rtInf;
  real_T rtMinusInf;
  real_T rtNaN;
  real32_T rtInfF;
  real32_T rtMinusInfF;
  real32_T rtNaNF;
}
//===========*
//  Constants *
// ===========
#define RT_PI                          3.14159265358979323846
#define RT_PIF                         3.1415927F
#define RT_LN_10                       2.30258509299404568402
#define RT_LN_10F                      2.3025851F
#define RT_LOG10E                      0.43429448190325182765
#define RT_LOG10EF                     0.43429449F
#define RT_E                           2.7182818284590452354
#define RT_EF                          2.7182817F

//
//  UNUSED_PARAMETER(x)
//    Used to specify that a function parameter (argument) is required but not
//    accessed by the function body.
#ifndef UNUSED_PARAMETER
#if defined(__LCC__)
#define UNUSED_PARAMETER(x)                                      // do nothing
#else

//
//  This is the semi-ANSI standard way of indicating that an
//  unused function parameter is required.
#define UNUSED_PARAMETER(x)            (void) (x)
#endif
#endif

extern "C" {
  //
  // Initialize rtInf needed by the generated code.
  // Inf is initialized as non-signaling. Assumes IEEE.
  //
  static real_T rtGetInf(void)
  {
    size_t bitsPerReal = sizeof(real_T) * (NumBitsPerChar);
    real_T inf = 0.0;
    if (bitsPerReal == 32U) {
      inf = rtGetInfF();
    } else {
      union {
        LittleEndianIEEEDouble bitVal;
        real_T fltVal;
      } tmpVal;

      tmpVal.bitVal.words.wordH = 0x7FF00000U;
      tmpVal.bitVal.words.wordL = 0x00000000U;
      inf = tmpVal.fltVal;
    }

    return inf;
  }

  //
  // Initialize rtInfF needed by the generated code.
  // Inf is initialized as non-signaling. Assumes IEEE.
  //
  static real32_T rtGetInfF(void)
  {
    IEEESingle infF;
    infF.wordL.wordLuint = 0x7F800000U;
    return infF.wordL.wordLreal;
  }

  //
  // Initialize rtMinusInf needed by the generated code.
  // Inf is initialized as non-signaling. Assumes IEEE.
  //
  static real_T rtGetMinusInf(void)
  {
    size_t bitsPerReal = sizeof(real_T) * (NumBitsPerChar);
    real_T minf = 0.0;
    if (bitsPerReal == 32U) {
      minf = rtGetMinusInfF();
    } else {
      union {
        LittleEndianIEEEDouble bitVal;
        real_T fltVal;
      } tmpVal;

      tmpVal.bitVal.words.wordH = 0xFFF00000U;
      tmpVal.bitVal.words.wordL = 0x00000000U;
      minf = tmpVal.fltVal;
    }

    return minf;
  }

  //
  // Initialize rtMinusInfF needed by the generated code.
  // Inf is initialized as non-signaling. Assumes IEEE.
  //
  static real32_T rtGetMinusInfF(void)
  {
    IEEESingle minfF;
    minfF.wordL.wordLuint = 0xFF800000U;
    return minfF.wordL.wordLreal;
  }
}
  extern "C"
{
  //
  // Initialize rtNaN needed by the generated code.
  // NaN is initialized as non-signaling. Assumes IEEE.
  //
  static real_T rtGetNaN(void)
  {
    size_t bitsPerReal = sizeof(real_T) * (NumBitsPerChar);
    real_T nan = 0.0;
    if (bitsPerReal == 32U) {
      nan = rtGetNaNF();
    } else {
      union {
        LittleEndianIEEEDouble bitVal;
        real_T fltVal;
      } tmpVal;

      tmpVal.bitVal.words.wordH = 0xFFF80000U;
      tmpVal.bitVal.words.wordL = 0x00000000U;
      nan = tmpVal.fltVal;
    }

    return nan;
  }

  //
  // Initialize rtNaNF needed by the generated code.
  // NaN is initialized as non-signaling. Assumes IEEE.
  //
  static real32_T rtGetNaNF(void)
  {
    IEEESingle nanF = { { 0.0F } };

    nanF.wordL.wordLuint = 0xFFC00000U;
    return nanF.wordL.wordLreal;
  }
}

extern "C" {
  //
  // Initialize the rtInf, rtMinusInf, and rtNaN needed by the
  // generated code. NaN is initialized as non-signaling. Assumes IEEE.
  //
  static void rt_InitInfAndNaN(size_t realSize)
  {
    (void) (realSize);
    rtNaN = rtGetNaN();
    rtNaNF = rtGetNaNF();
    rtInf = rtGetInf();
    rtInfF = rtGetInfF();
    rtMinusInf = rtGetMinusInf();
    rtMinusInfF = rtGetMinusInfF();
  }

  // Test if value is infinite
  static boolean_T rtIsInf(real_T value)
  {
    return (boolean_T)((value==rtInf || value==rtMinusInf) ? 1U : 0U);
  }

  // Test if single-precision value is infinite
  static boolean_T rtIsInfF(real32_T value)
  {
    return (boolean_T)(((value)==rtInfF || (value)==rtMinusInfF) ? 1U : 0U);
  }

  // Test if value is not a number
  static boolean_T rtIsNaN(real_T value)
  {
    boolean_T result = (boolean_T) 0;
    size_t bitsPerReal = sizeof(real_T) * (NumBitsPerChar);
    if (bitsPerReal == 32U) {
      result = rtIsNaNF((real32_T)value);
    } else {
      union {
        LittleEndianIEEEDouble bitVal;
        real_T fltVal;
      } tmpVal;

      tmpVal.fltVal = value;
      result = (boolean_T)((tmpVal.bitVal.words.wordH & 0x7FF00000) ==
                           0x7FF00000 &&
                           ( (tmpVal.bitVal.words.wordH & 0x000FFFFF) != 0 ||
                            (tmpVal.bitVal.words.wordL != 0) ));
    }

    return result;
  }

  // Test if single-precision value is not a number
  static boolean_T rtIsNaNF(real32_T value)
  {
    IEEESingle tmp;
    tmp.wordL.wordLreal = value;
    return (boolean_T)( (tmp.wordL.wordLuint & 0x7F800000) == 0x7F800000 &&
                       (tmp.wordL.wordLuint & 0x007FFFFF) != 0 );
  }
}
  namespace bfs
{
  // Model step function
  void Autocode::Run(const SysData &sys, const SensorData &sensor, const NavData
                     &nav, const TelemData &telem, ControlData *ctrl)
  {
    std::array<real_T, 8> rtb_Switch;
    int32_T i;
    int32_T rtb_Reshape_l_tmp;
    real32_T rtb_IProdOut;
    real32_T rtb_IProdOut_0;
    real32_T rtb_Integrator_h;
    real32_T rtb_Integrator_j;
    real32_T rtb_Integrator_k;
    real32_T rtb_Integrator_n;
    real32_T rtb_SignPreIntegrator;
    real32_T rtb_Switch_ab;
    real32_T rtb_Switch_g;
    real32_T rtb_Switch_m;
    real32_T rtb_Switch_n;
    real32_T rtb_Tsamp;
    real32_T rtb_Tsamp_bz;
    real32_T rtb_Tsamp_e;
    boolean_T rtb_AND;
    boolean_T rtb_NotEqual_d;
    UNUSED_PARAMETER(sys);

    // Logic: '<Root>/AND' incorporates:
    //   Inport: '<Root>/Navigation Filter Data'
    //   Inport: '<Root>/Sensor Data'
    rtb_AND = (sensor.inceptor.throttle_en && nav.nav_initialized);

    // Outputs for Enabled SubSystem: '<Root>/STABILIZED CONTROLER' incorporates:
    //   EnablePort: '<S5>/Enable'

    // Logic: '<Root>/AND1' incorporates:
    //   Constant: '<S2>/Constant'
    //   Inport: '<Root>/Sensor Data'
    //   RelationalOperator: '<S2>/Compare'
    if (rtb_AND && (sensor.inceptor.mode0 == 0)) {
      // SignalConversion generated from: '<S5>/Command out'
      rtDW.throttle = sensor.inceptor.throttle;

      // Sum: '<S338>/Sum2' incorporates:
      //   Gain: '<S338>/Gain'
      //   Inport: '<Root>/Navigation Filter Data'
      rtb_Integrator_n = -0.262F * sensor.inceptor.pitch - nav.pitch_rad;

      // Product: '<S374>/IProd Out' incorporates:
      //   Inport: '<Root>/Telemetry Data'
      rtb_Integrator_j = rtb_Integrator_n * telem.param[1];

      // SampleTimeMath: '<S372>/Tsamp' incorporates:
      //   Inport: '<Root>/Telemetry Data'
      //   Product: '<S369>/DProd Out'
      //
      //  About '<S372>/Tsamp':
      //   y = u * K where K = 1 / ( w * Ts )
      rtb_Tsamp = rtb_Integrator_n * telem.param[2] * 50.0F;

      // Sum: '<S386>/Sum' incorporates:
      //   Delay: '<S370>/UD'
      //   DiscreteIntegrator: '<S377>/Integrator'
      //   Inport: '<Root>/Telemetry Data'
      //   Product: '<S382>/PProd Out'
      //   Sum: '<S370>/Diff'
      rtb_SignPreIntegrator = (rtb_Integrator_n * telem.param[0] +
        rtDW.Integrator_DSTATE) + (rtb_Tsamp - rtDW.UD_DSTATE);

      // DeadZone: '<S368>/DeadZone'
      if (rtb_SignPreIntegrator >= (rtMinusInfF)) {
        rtb_Switch_n = 0.0F;
      } else {
        rtb_Switch_n = (rtNaNF);
      }

      // End of DeadZone: '<S368>/DeadZone'

      // Signum: '<S366>/SignPreIntegrator'
      if (rtb_Integrator_j < 0.0F) {
        rtb_Switch_g = -1.0F;
      } else if (rtb_Integrator_j > 0.0F) {
        rtb_Switch_g = 1.0F;
      } else if (rtb_Integrator_j == 0.0F) {
        rtb_Switch_g = 0.0F;
      } else {
        rtb_Switch_g = (rtNaNF);
      }

      // End of Signum: '<S366>/SignPreIntegrator'

      // Switch: '<S366>/Switch' incorporates:
      //   Constant: '<S366>/Constant1'
      //   DataTypeConversion: '<S366>/DataTypeConv2'
      //   Gain: '<S366>/ZeroGain'
      //   Logic: '<S366>/AND3'
      //   RelationalOperator: '<S366>/Equal1'
      //   RelationalOperator: '<S366>/NotEqual'
      if ((0.0F * rtb_SignPreIntegrator != rtb_Switch_n) && (0 ==
           static_cast<int8_T>(rtb_Switch_g))) {
        rtb_Switch_ab = 0.0F;
      } else {
        rtb_Switch_ab = rtb_Integrator_j;
      }

      // End of Switch: '<S366>/Switch'

      // Saturate: '<S384>/Saturation'
      rtDW.Saturation = rtb_SignPreIntegrator;

      // Sum: '<S339>/Sum' incorporates:
      //   Gain: '<S339>/Gain'
      //   Inport: '<Root>/Navigation Filter Data'
      //   SignalConversion generated from: '<S339>/Bus Selector'
      rtb_SignPreIntegrator = 0.262F * sensor.inceptor.roll - nav.roll_rad;

      // Product: '<S427>/IProd Out' incorporates:
      //   Inport: '<Root>/Telemetry Data'
      rtb_Integrator_j = rtb_SignPreIntegrator * telem.param[1];

      // SampleTimeMath: '<S425>/Tsamp' incorporates:
      //   Inport: '<Root>/Telemetry Data'
      //   Product: '<S422>/DProd Out'
      //
      //  About '<S425>/Tsamp':
      //   y = u * K where K = 1 / ( w * Ts )
      rtb_Tsamp_bz = rtb_SignPreIntegrator * telem.param[2] * 50.0F;

      // Sum: '<S439>/Sum' incorporates:
      //   Delay: '<S423>/UD'
      //   DiscreteIntegrator: '<S430>/Integrator'
      //   Inport: '<Root>/Telemetry Data'
      //   Product: '<S435>/PProd Out'
      //   Sum: '<S423>/Diff'
      rtb_Integrator_n = (rtb_SignPreIntegrator * telem.param[0] +
                          rtDW.Integrator_DSTATE_g) + (rtb_Tsamp_bz -
        rtDW.UD_DSTATE_d);

      // DeadZone: '<S421>/DeadZone'
      if (rtb_Integrator_n >= (rtMinusInfF)) {
        rtb_Integrator_k = 0.0F;
      } else {
        rtb_Integrator_k = (rtNaNF);
      }

      // End of DeadZone: '<S421>/DeadZone'

      // Signum: '<S419>/SignPreIntegrator'
      if (rtb_Integrator_j < 0.0F) {
        rtb_Switch_g = -1.0F;
      } else if (rtb_Integrator_j > 0.0F) {
        rtb_Switch_g = 1.0F;
      } else if (rtb_Integrator_j == 0.0F) {
        rtb_Switch_g = 0.0F;
      } else {
        rtb_Switch_g = (rtNaNF);
      }

      // End of Signum: '<S419>/SignPreIntegrator'

      // Switch: '<S419>/Switch' incorporates:
      //   Constant: '<S419>/Constant1'
      //   DataTypeConversion: '<S419>/DataTypeConv2'
      //   Gain: '<S419>/ZeroGain'
      //   Logic: '<S419>/AND3'
      //   RelationalOperator: '<S419>/Equal1'
      //   RelationalOperator: '<S419>/NotEqual'
      if ((0.0F * rtb_Integrator_n != rtb_Integrator_k) && (0 ==
           static_cast<int8_T>(rtb_Switch_g))) {
        rtb_Switch_g = 0.0F;
      } else {
        rtb_Switch_g = rtb_Integrator_j;
      }

      // End of Switch: '<S419>/Switch'

      // Saturate: '<S437>/Saturation'
      rtDW.Saturation_i = rtb_Integrator_n;

      // Sum: '<S340>/Sum1' incorporates:
      //   Gain: '<S340>/Saturation Gain'
      //   Inport: '<Root>/Navigation Filter Data'
      rtb_SignPreIntegrator = 0.349F * sensor.inceptor.yaw - nav.gyro_radps[2];

      // Product: '<S480>/IProd Out' incorporates:
      //   Inport: '<Root>/Telemetry Data'
      rtb_Integrator_j = rtb_SignPreIntegrator * telem.param[4];

      // SampleTimeMath: '<S478>/Tsamp' incorporates:
      //   Inport: '<Root>/Telemetry Data'
      //   Product: '<S475>/DProd Out'
      //
      //  About '<S478>/Tsamp':
      //   y = u * K where K = 1 / ( w * Ts )
      rtb_Tsamp_e = rtb_SignPreIntegrator * telem.param[5] * 50.0F;

      // Sum: '<S492>/Sum' incorporates:
      //   Delay: '<S476>/UD'
      //   DiscreteIntegrator: '<S483>/Integrator'
      //   Inport: '<Root>/Telemetry Data'
      //   Product: '<S488>/PProd Out'
      //   Sum: '<S476>/Diff'
      rtb_Integrator_n = (rtb_SignPreIntegrator * telem.param[3] +
                          rtDW.Integrator_DSTATE_f) + (rtb_Tsamp_e -
        rtDW.UD_DSTATE_l);

      // Saturate: '<S490>/Saturation'
      rtDW.Saturation_d = rtb_Integrator_n;

      // Update for DiscreteIntegrator: '<S377>/Integrator'
      rtDW.Integrator_DSTATE += 0.02F * rtb_Switch_ab;

      // Update for Delay: '<S370>/UD'
      rtDW.UD_DSTATE = rtb_Tsamp;

      // Update for DiscreteIntegrator: '<S430>/Integrator'
      rtDW.Integrator_DSTATE_g += 0.02F * rtb_Switch_g;

      // Update for Delay: '<S423>/UD'
      rtDW.UD_DSTATE_d = rtb_Tsamp_bz;

      // DeadZone: '<S474>/DeadZone'
      if (rtb_Integrator_n >= (rtMinusInfF)) {
        rtb_Integrator_k = 0.0F;
      } else {
        rtb_Integrator_k = (rtNaNF);
      }

      // End of DeadZone: '<S474>/DeadZone'

      // Signum: '<S472>/SignPreIntegrator'
      if (rtb_Integrator_j < 0.0F) {
        rtb_Switch_g = -1.0F;
      } else if (rtb_Integrator_j > 0.0F) {
        rtb_Switch_g = 1.0F;
      } else if (rtb_Integrator_j == 0.0F) {
        rtb_Switch_g = 0.0F;
      } else {
        rtb_Switch_g = (rtNaNF);
      }

      // End of Signum: '<S472>/SignPreIntegrator'

      // Switch: '<S472>/Switch' incorporates:
      //   Constant: '<S472>/Constant1'
      //   DataTypeConversion: '<S472>/DataTypeConv2'
      //   Gain: '<S472>/ZeroGain'
      //   Logic: '<S472>/AND3'
      //   RelationalOperator: '<S472>/Equal1'
      //   RelationalOperator: '<S472>/NotEqual'
      if ((0.0F * rtb_Integrator_n != rtb_Integrator_k) && (0 ==
           static_cast<int8_T>(rtb_Switch_g))) {
        rtb_Integrator_j = 0.0F;
      }

      // End of Switch: '<S472>/Switch'

      // Update for DiscreteIntegrator: '<S483>/Integrator'
      rtDW.Integrator_DSTATE_f += 0.02F * rtb_Integrator_j;

      // Update for Delay: '<S476>/UD'
      rtDW.UD_DSTATE_l = rtb_Tsamp_e;
    }

    // End of Logic: '<Root>/AND1'
    // End of Outputs for SubSystem: '<Root>/STABILIZED CONTROLER'

    // Outputs for Enabled SubSystem: '<Root>/POS_HOLD CONTROLLER' incorporates:
    //   EnablePort: '<S4>/Enable'

    // Logic: '<Root>/AND2' incorporates:
    //   Constant: '<S1>/Constant'
    //   Inport: '<Root>/Sensor Data'
    //   RelationalOperator: '<S1>/Compare'
    if (rtb_AND && (sensor.inceptor.mode0 == 1)) {
      // Trigonometry: '<S10>/Cos' incorporates:
      //   Inport: '<Root>/Navigation Filter Data'
      //   SignalConversion generated from: '<S7>/Bus Selector'
      rtb_SignPreIntegrator = std::cos(nav.heading_rad);

      // Trigonometry: '<S10>/Sin' incorporates:
      //   Inport: '<Root>/Navigation Filter Data'
      //   SignalConversion generated from: '<S7>/Bus Selector'
      rtb_Integrator_j = std::sin(nav.heading_rad);

      // Product: '<S7>/Product' incorporates:
      //   Inport: '<Root>/Navigation Filter Data'
      //   Reshape: '<S10>/Reshape'
      //   SignalConversion generated from: '<S7>/Bus Selector'
      rtb_Tsamp_e = rtb_SignPreIntegrator * nav.ned_vel_mps[0] +
        rtb_Integrator_j * nav.ned_vel_mps[1];

      // Sum: '<S14>/Sum' incorporates:
      //   Gain: '<S10>/Gain'
      //   Inport: '<Root>/Navigation Filter Data'
      //   Product: '<S7>/Product'
      //   Reshape: '<S10>/Reshape'
      //   SignalConversion generated from: '<S7>/Bus Selector'
      rtb_Integrator_j = sensor.inceptor.roll - (-rtb_Integrator_j *
        nav.ned_vel_mps[0] + rtb_SignPreIntegrator * nav.ned_vel_mps[1]);

      // SampleTimeMath: '<S205>/Tsamp' incorporates:
      //   Constant: '<S14>/Constant2'
      //   Product: '<S202>/DProd Out'
      //
      //  About '<S205>/Tsamp':
      //   y = u * K where K = 1 / ( w * Ts )
      rtb_Tsamp = rtb_Integrator_j * 0.0F * 50.0F;

      // Sum: '<S219>/Sum' incorporates:
      //   Constant: '<S14>/Constant'
      //   Delay: '<S203>/UD'
      //   DiscreteIntegrator: '<S210>/Integrator'
      //   Product: '<S215>/PProd Out'
      //   Sum: '<S203>/Diff'
      rtb_Switch_g = (rtb_Integrator_j * 0.0F + rtDW.Integrator_DSTATE_m) +
        (rtb_Tsamp - rtDW.UD_DSTATE_m);

      // Saturate: '<S14>/Saturation'
      if (rtb_Switch_g > 0.262F) {
        rtb_SignPreIntegrator = 0.262F;
      } else if (rtb_Switch_g < -0.262F) {
        rtb_SignPreIntegrator = -0.262F;
      } else {
        rtb_SignPreIntegrator = rtb_Switch_g;
      }

      // End of Saturate: '<S14>/Saturation'

      // Sum: '<S12>/Sum' incorporates:
      //   Inport: '<Root>/Navigation Filter Data'
      rtb_SignPreIntegrator -= nav.roll_rad;

      // SampleTimeMath: '<S99>/Tsamp' incorporates:
      //   Constant: '<S12>/D_roll_angle'
      //   Product: '<S96>/DProd Out'
      //
      //  About '<S99>/Tsamp':
      //   y = u * K where K = 1 / ( w * Ts )
      rtb_Switch_ab = rtb_SignPreIntegrator * 0.12F * 50.0F;

      // Sum: '<S113>/Sum' incorporates:
      //   Constant: '<S12>/P_roll_angle'
      //   Delay: '<S97>/UD'
      //   DiscreteIntegrator: '<S104>/Integrator'
      //   Product: '<S109>/PProd Out'
      //   Sum: '<S97>/Diff'
      rtb_Integrator_n = (rtb_SignPreIntegrator * 0.7F +
                          rtDW.Integrator_DSTATE_a) + (rtb_Switch_ab -
        rtDW.UD_DSTATE_lt);

      // Product: '<S101>/IProd Out' incorporates:
      //   Constant: '<S12>/I_roll_angle'
      rtb_SignPreIntegrator *= 0.1F;

      // DeadZone: '<S95>/DeadZone'
      if (rtb_Integrator_n >= (rtMinusInfF)) {
        rtb_Integrator_k = 0.0F;
      } else {
        rtb_Integrator_k = (rtNaNF);
      }

      // End of DeadZone: '<S95>/DeadZone'

      // Signum: '<S93>/SignPreIntegrator'
      if (rtb_SignPreIntegrator < 0.0F) {
        rtb_Switch_n = -1.0F;
      } else if (rtb_SignPreIntegrator > 0.0F) {
        rtb_Switch_n = 1.0F;
      } else if (rtb_SignPreIntegrator == 0.0F) {
        rtb_Switch_n = 0.0F;
      } else {
        rtb_Switch_n = (rtNaNF);
      }

      // End of Signum: '<S93>/SignPreIntegrator'

      // Switch: '<S93>/Switch' incorporates:
      //   Constant: '<S93>/Constant1'
      //   DataTypeConversion: '<S93>/DataTypeConv2'
      //   Gain: '<S93>/ZeroGain'
      //   Logic: '<S93>/AND3'
      //   RelationalOperator: '<S93>/Equal1'
      //   RelationalOperator: '<S93>/NotEqual'
      if ((0.0F * rtb_Integrator_n != rtb_Integrator_k) && (0 ==
           static_cast<int8_T>(rtb_Switch_n))) {
        rtb_Tsamp_bz = 0.0F;
      } else {
        rtb_Tsamp_bz = rtb_SignPreIntegrator;
      }

      // End of Switch: '<S93>/Switch'

      // Saturate: '<S111>/Saturation'
      rtDW.Saturation_f = rtb_Integrator_n;

      // Gain: '<S199>/ZeroGain'
      rtb_SignPreIntegrator = 0.0F * rtb_Switch_g;

      // DeadZone: '<S201>/DeadZone'
      if (rtb_Switch_g >= (rtMinusInfF)) {
        rtb_Switch_g = 0.0F;
      }

      // End of DeadZone: '<S201>/DeadZone'

      // RelationalOperator: '<S199>/NotEqual'
      rtb_NotEqual_d = (rtb_SignPreIntegrator != rtb_Switch_g);

      // Product: '<S207>/IProd Out' incorporates:
      //   Constant: '<S14>/Constant1'
      rtb_Integrator_j *= 0.0F;

      // Sum: '<S13>/Sum' incorporates:
      //   SignalConversion generated from: '<S7>/Bus Selector'
      rtb_Integrator_k = sensor.inceptor.pitch - rtb_Tsamp_e;

      // SampleTimeMath: '<S152>/Tsamp' incorporates:
      //   Constant: '<S13>/Constant2'
      //   Product: '<S149>/DProd Out'
      //
      //  About '<S152>/Tsamp':
      //   y = u * K where K = 1 / ( w * Ts )
      rtb_Integrator_n = rtb_Integrator_k * 0.0001F * 50.0F;

      // Sum: '<S166>/Sum' incorporates:
      //   Constant: '<S13>/Constant'
      //   Delay: '<S150>/UD'
      //   DiscreteIntegrator: '<S157>/Integrator'
      //   Product: '<S162>/PProd Out'
      //   Sum: '<S150>/Diff'
      rtb_Switch_g = (rtb_Integrator_k * 0.001F + rtDW.Integrator_DSTATE_p) +
        (rtb_Integrator_n - rtDW.UD_DSTATE_n);

      // Saturate: '<S13>/Saturation'
      if (rtb_Switch_g > 0.262F) {
        rtb_SignPreIntegrator = 0.262F;
      } else if (rtb_Switch_g < -0.262F) {
        rtb_SignPreIntegrator = -0.262F;
      } else {
        rtb_SignPreIntegrator = rtb_Switch_g;
      }

      // End of Saturate: '<S13>/Saturation'

      // Sum: '<S11>/Sum2' incorporates:
      //   Gain: '<S13>/Gain'
      //   Inport: '<Root>/Navigation Filter Data'
      rtb_SignPreIntegrator = -rtb_SignPreIntegrator - nav.pitch_rad;

      // SampleTimeMath: '<S46>/Tsamp' incorporates:
      //   Constant: '<S11>/D_pitch_angle'
      //   Product: '<S43>/DProd Out'
      //
      //  About '<S46>/Tsamp':
      //   y = u * K where K = 1 / ( w * Ts )
      rtb_Tsamp_e = rtb_SignPreIntegrator * 0.1F * 50.0F;

      // Sum: '<S60>/Sum' incorporates:
      //   Constant: '<S11>/P_pitch_angle'
      //   Delay: '<S44>/UD'
      //   DiscreteIntegrator: '<S51>/Integrator'
      //   Product: '<S56>/PProd Out'
      //   Sum: '<S44>/Diff'
      rtb_IProdOut = (rtb_SignPreIntegrator * 0.7F + rtDW.Integrator_DSTATE_p5)
        + (rtb_Tsamp_e - rtDW.UD_DSTATE_p);

      // Product: '<S48>/IProd Out' incorporates:
      //   Constant: '<S11>/I_pitch_angle'
      rtb_SignPreIntegrator *= 0.12F;

      // DeadZone: '<S42>/DeadZone'
      if (rtb_IProdOut >= (rtMinusInfF)) {
        rtb_IProdOut_0 = 0.0F;
      } else {
        rtb_IProdOut_0 = (rtNaNF);
      }

      // End of DeadZone: '<S42>/DeadZone'

      // Signum: '<S40>/SignPreIntegrator'
      if (rtb_SignPreIntegrator < 0.0F) {
        rtb_Switch_n = -1.0F;
      } else if (rtb_SignPreIntegrator > 0.0F) {
        rtb_Switch_n = 1.0F;
      } else if (rtb_SignPreIntegrator == 0.0F) {
        rtb_Switch_n = 0.0F;
      } else {
        rtb_Switch_n = (rtNaNF);
      }

      // End of Signum: '<S40>/SignPreIntegrator'

      // Switch: '<S40>/Switch' incorporates:
      //   Constant: '<S40>/Constant1'
      //   DataTypeConversion: '<S40>/DataTypeConv2'
      //   Gain: '<S40>/ZeroGain'
      //   Logic: '<S40>/AND3'
      //   RelationalOperator: '<S40>/Equal1'
      //   RelationalOperator: '<S40>/NotEqual'
      if ((0.0F * rtb_IProdOut != rtb_IProdOut_0) && (0 == static_cast<int8_T>
           (rtb_Switch_n))) {
        rtb_Switch_n = 0.0F;
      } else {
        rtb_Switch_n = rtb_SignPreIntegrator;
      }

      // End of Switch: '<S40>/Switch'

      // Saturate: '<S58>/Saturation'
      rtDW.Saturation_j = rtb_IProdOut;

      // Gain: '<S146>/ZeroGain'
      rtb_SignPreIntegrator = 0.0F * rtb_Switch_g;

      // DeadZone: '<S148>/DeadZone'
      if (rtb_Switch_g >= (rtMinusInfF)) {
        rtb_Switch_g = 0.0F;
      }

      // End of DeadZone: '<S148>/DeadZone'

      // Product: '<S154>/IProd Out' incorporates:
      //   Constant: '<S13>/Constant1'
      rtb_Integrator_k *= 0.0001F;

      // Signum: '<S146>/SignPreIntegrator'
      if (rtb_Integrator_k < 0.0F) {
        rtb_IProdOut = -1.0F;
      } else if (rtb_Integrator_k > 0.0F) {
        rtb_IProdOut = 1.0F;
      } else if (rtb_Integrator_k == 0.0F) {
        rtb_IProdOut = 0.0F;
      } else {
        rtb_IProdOut = (rtNaNF);
      }

      // End of Signum: '<S146>/SignPreIntegrator'

      // Switch: '<S146>/Switch' incorporates:
      //   Constant: '<S146>/Constant1'
      //   DataTypeConversion: '<S146>/DataTypeConv2'
      //   Logic: '<S146>/AND3'
      //   RelationalOperator: '<S146>/Equal1'
      //   RelationalOperator: '<S146>/NotEqual'
      if ((rtb_SignPreIntegrator != rtb_Switch_g) && (0 == static_cast<int8_T>
           (rtb_IProdOut))) {
        rtb_Switch_m = 0.0F;
      } else {
        rtb_Switch_m = rtb_Integrator_k;
      }

      // End of Switch: '<S146>/Switch'

      // Product: '<S228>/v_z_cmd (-1 to 1)' incorporates:
      //   Constant: '<S228>/Double'
      //   Constant: '<S228>/Normalize at Zero'
      //   Sum: '<S228>/Sum'
      rtb_Integrator_h = (sensor.inceptor.throttle - 0.5F) * 2.0F;

      // Sum: '<S8>/Sum' incorporates:
      //   Constant: '<S228>/Constant'
      //   Constant: '<S228>/Constant1'
      //   Constant: '<S281>/Constant'
      //   Constant: '<S282>/Constant'
      //   Inport: '<Root>/Navigation Filter Data'
      //   Product: '<S228>/Product'
      //   Product: '<S228>/Product1'
      //   RelationalOperator: '<S281>/Compare'
      //   RelationalOperator: '<S282>/Compare'
      //   Sum: '<S228>/Sum1'
      rtb_IProdOut = (static_cast<real32_T>(rtb_Integrator_h < 0.0F) * 0.5F *
                      rtb_Integrator_h + static_cast<real32_T>(rtb_Integrator_h >=
        0.0F) * rtb_Integrator_h * 0.5F) + nav.ned_vel_mps[2];

      // SampleTimeMath: '<S259>/Tsamp' incorporates:
      //   Constant: '<S8>/D_vz'
      //   Product: '<S256>/DProd Out'
      //
      //  About '<S259>/Tsamp':
      //   y = u * K where K = 1 / ( w * Ts )
      rtb_Integrator_h = rtb_IProdOut * 0.01F * 50.0F;

      // Sum: '<S273>/Sum' incorporates:
      //   Constant: '<S8>/P_vz'
      //   Delay: '<S257>/UD'
      //   DiscreteIntegrator: '<S264>/Integrator'
      //   Product: '<S269>/PProd Out'
      //   Sum: '<S257>/Diff'
      rtb_Integrator_k = (rtb_IProdOut * 0.5F + rtDW.Integrator_DSTATE_h) +
        (rtb_Integrator_h - rtDW.UD_DSTATE_ms);

      // Saturate: '<S8>/Saturation' incorporates:
      //   Constant: '<S8>/Constant2'
      //   Sum: '<S8>/Sum1'
      if (rtb_Integrator_k + 0.9F > 1.0F) {
        // Saturate: '<S8>/Saturation'
        rtDW.Saturation_a = 1.0F;
      } else if (rtb_Integrator_k + 0.9F < 0.0F) {
        // Saturate: '<S8>/Saturation'
        rtDW.Saturation_a = 0.0F;
      } else {
        // Saturate: '<S8>/Saturation'
        rtDW.Saturation_a = rtb_Integrator_k + 0.9F;
      }

      // End of Saturate: '<S8>/Saturation'

      // Gain: '<S253>/ZeroGain'
      rtb_SignPreIntegrator = 0.0F * rtb_Integrator_k;

      // DeadZone: '<S255>/DeadZone'
      if (rtb_Integrator_k >= (rtMinusInfF)) {
        rtb_Integrator_k = 0.0F;
      }

      // End of DeadZone: '<S255>/DeadZone'

      // Product: '<S261>/IProd Out' incorporates:
      //   Constant: '<S8>/I_vz'
      rtb_IProdOut *= 0.01F;

      // Signum: '<S253>/SignPreIntegrator'
      if (rtb_IProdOut < 0.0F) {
        rtb_IProdOut_0 = -1.0F;
      } else if (rtb_IProdOut > 0.0F) {
        rtb_IProdOut_0 = 1.0F;
      } else if (rtb_IProdOut == 0.0F) {
        rtb_IProdOut_0 = 0.0F;
      } else {
        rtb_IProdOut_0 = (rtNaNF);
      }

      // End of Signum: '<S253>/SignPreIntegrator'

      // Switch: '<S253>/Switch' incorporates:
      //   Constant: '<S253>/Constant1'
      //   DataTypeConversion: '<S253>/DataTypeConv2'
      //   Logic: '<S253>/AND3'
      //   RelationalOperator: '<S253>/Equal1'
      //   RelationalOperator: '<S253>/NotEqual'
      if ((rtb_SignPreIntegrator != rtb_Integrator_k) && (0 ==
           static_cast<int8_T>(rtb_IProdOut_0))) {
        rtb_Integrator_k = 0.0F;
      } else {
        rtb_Integrator_k = rtb_IProdOut;
      }

      // End of Switch: '<S253>/Switch'

      // Sum: '<S9>/Sum1' incorporates:
      //   Gain: '<S9>/Saturation Gain'
      //   Inport: '<Root>/Navigation Filter Data'
      rtb_IProdOut = 0.349F * sensor.inceptor.yaw - nav.gyro_radps[2];

      // SampleTimeMath: '<S314>/Tsamp' incorporates:
      //   Constant: '<S9>/D_yaw_rate'
      //   Product: '<S311>/DProd Out'
      //
      //  About '<S314>/Tsamp':
      //   y = u * K where K = 1 / ( w * Ts )
      rtb_SignPreIntegrator = rtb_IProdOut * 0.1F * 50.0F;

      // Sum: '<S328>/Sum' incorporates:
      //   Constant: '<S9>/P_yaw_rate'
      //   Delay: '<S312>/UD'
      //   DiscreteIntegrator: '<S319>/Integrator'
      //   Product: '<S324>/PProd Out'
      //   Sum: '<S312>/Diff'
      rtb_Switch_g = (rtb_IProdOut * 0.6F + rtDW.Integrator_DSTATE_d) +
        (rtb_SignPreIntegrator - rtDW.UD_DSTATE_pt);

      // Product: '<S316>/IProd Out' incorporates:
      //   Constant: '<S9>/I_yaw_rate'
      rtb_IProdOut *= 0.1F;

      // Saturate: '<S326>/Saturation'
      rtDW.Saturation_h = rtb_Switch_g;

      // Switch: '<S199>/Switch' incorporates:
      //   Constant: '<S199>/Constant1'
      //   Logic: '<S199>/AND3'
      if (rtb_NotEqual_d) {
        rtb_Integrator_j = 0.0F;
      }

      // End of Switch: '<S199>/Switch'

      // Update for DiscreteIntegrator: '<S210>/Integrator'
      rtDW.Integrator_DSTATE_m += 0.02F * rtb_Integrator_j;

      // Update for Delay: '<S203>/UD'
      rtDW.UD_DSTATE_m = rtb_Tsamp;

      // Update for DiscreteIntegrator: '<S104>/Integrator'
      rtDW.Integrator_DSTATE_a += 0.02F * rtb_Tsamp_bz;

      // Update for Delay: '<S97>/UD'
      rtDW.UD_DSTATE_lt = rtb_Switch_ab;

      // Update for DiscreteIntegrator: '<S157>/Integrator'
      rtDW.Integrator_DSTATE_p += 0.02F * rtb_Switch_m;

      // Update for Delay: '<S150>/UD'
      rtDW.UD_DSTATE_n = rtb_Integrator_n;

      // Update for DiscreteIntegrator: '<S51>/Integrator'
      rtDW.Integrator_DSTATE_p5 += 0.02F * rtb_Switch_n;

      // Update for Delay: '<S44>/UD'
      rtDW.UD_DSTATE_p = rtb_Tsamp_e;

      // Update for DiscreteIntegrator: '<S264>/Integrator'
      rtDW.Integrator_DSTATE_h += 0.02F * rtb_Integrator_k;

      // Update for Delay: '<S257>/UD'
      rtDW.UD_DSTATE_ms = rtb_Integrator_h;

      // Update for Delay: '<S312>/UD'
      rtDW.UD_DSTATE_pt = rtb_SignPreIntegrator;

      // DeadZone: '<S310>/DeadZone'
      if (rtb_Switch_g >= (rtMinusInfF)) {
        rtb_SignPreIntegrator = 0.0F;
      } else {
        rtb_SignPreIntegrator = (rtNaNF);
      }

      // End of DeadZone: '<S310>/DeadZone'

      // Signum: '<S308>/SignPreIntegrator'
      if (rtb_IProdOut < 0.0F) {
        rtb_IProdOut_0 = -1.0F;
      } else if (rtb_IProdOut > 0.0F) {
        rtb_IProdOut_0 = 1.0F;
      } else if (rtb_IProdOut == 0.0F) {
        rtb_IProdOut_0 = 0.0F;
      } else {
        rtb_IProdOut_0 = (rtNaNF);
      }

      // End of Signum: '<S308>/SignPreIntegrator'

      // Switch: '<S308>/Switch' incorporates:
      //   Constant: '<S308>/Constant1'
      //   DataTypeConversion: '<S308>/DataTypeConv2'
      //   Gain: '<S308>/ZeroGain'
      //   Logic: '<S308>/AND3'
      //   RelationalOperator: '<S308>/Equal1'
      //   RelationalOperator: '<S308>/NotEqual'
      if ((0.0F * rtb_Switch_g != rtb_SignPreIntegrator) && (0 ==
           static_cast<int8_T>(rtb_IProdOut_0))) {
        rtb_IProdOut = 0.0F;
      }

      // End of Switch: '<S308>/Switch'

      // Update for DiscreteIntegrator: '<S319>/Integrator'
      rtDW.Integrator_DSTATE_d += 0.02F * rtb_IProdOut;
    }

    // End of Logic: '<Root>/AND2'
    // End of Outputs for SubSystem: '<Root>/POS_HOLD CONTROLLER'

    // Switch: '<Root>/Switch'
    if (rtb_AND) {
      // MultiPortSwitch generated from: '<Root>/Multiport Switch' incorporates:
      //   Inport: '<Root>/Sensor Data'
      switch (sensor.inceptor.mode0) {
       case 0:
        rtb_SignPreIntegrator = rtDW.Saturation_d;
        rtb_Integrator_j = rtDW.Saturation;
        rtb_Tsamp = rtDW.Saturation_i;
        rtb_Switch_ab = rtDW.throttle;
        break;

       case 1:
        rtb_SignPreIntegrator = rtDW.Saturation_h;
        rtb_Integrator_j = rtDW.Saturation_j;
        rtb_Tsamp = rtDW.Saturation_f;
        rtb_Switch_ab = rtDW.Saturation_a;
        break;

       default:
        rtb_SignPreIntegrator = 0.0F;
        rtb_Integrator_j = 0.0F;
        rtb_Tsamp = 0.0F;
        rtb_Switch_ab = 0.0F;
        break;
      }

      // End of MultiPortSwitch generated from: '<Root>/Multiport Switch'

      // Product: '<S3>/Multiply' incorporates:
      //   Math: '<S3>/Transpose'
      //   Reshape: '<S3>/Reshape'
      for (i = 0; i < 8; i++) {
        rtb_Reshape_l_tmp = i << 2;
        rtb_Integrator_n = rtConstB.Transpose[rtb_Reshape_l_tmp + 3] *
          rtb_SignPreIntegrator + (rtConstB.Transpose[rtb_Reshape_l_tmp + 2] *
          rtb_Integrator_j + (rtConstB.Transpose[rtb_Reshape_l_tmp + 1] *
                              rtb_Tsamp + rtConstB.Transpose[rtb_Reshape_l_tmp] *
                              rtb_Switch_ab));

        // Saturate: '<S3>/Saturation' incorporates:
        //   Math: '<S3>/Transpose'
        //   Reshape: '<S3>/Reshape'
        if (rtb_Integrator_n <= 0.0F) {
          rtb_Switch[i] = 0.0;
        } else {
          rtb_Switch[i] = rtb_Integrator_n;
        }

        // End of Saturate: '<S3>/Saturation'
      }

      // End of Product: '<S3>/Multiply'
    } else {
      std::memset(&rtb_Switch[0], 0, sizeof(real_T) << 3U);
    }

    // End of Switch: '<Root>/Switch'

    // Outport: '<Root>/Control Data' incorporates:
    //   BusCreator: '<S6>/Bus Creator2'
    //   Constant: '<S501>/Constant1'
    //   Constant: '<S501>/Constant10'
    //   Constant: '<S501>/Constant11'
    //   Constant: '<S501>/Constant12'
    //   Constant: '<S501>/Constant13'
    //   Constant: '<S501>/Constant14'
    //   Constant: '<S501>/Constant15'
    //   Constant: '<S501>/Constant16'
    //   Constant: '<S501>/Constant17'
    //   Constant: '<S501>/Constant18'
    //   Constant: '<S501>/Constant19'
    //   Constant: '<S501>/Constant2'
    //   Constant: '<S501>/Constant20'
    //   Constant: '<S501>/Constant21'
    //   Constant: '<S501>/Constant22'
    //   Constant: '<S501>/Constant23'
    //   Constant: '<S501>/Constant24'
    //   Constant: '<S501>/Constant25'
    //   Constant: '<S501>/Constant26'
    //   Constant: '<S501>/Constant27'
    //   Constant: '<S501>/Constant28'
    //   Constant: '<S501>/Constant29'
    //   Constant: '<S501>/Constant3'
    //   Constant: '<S501>/Constant30'
    //   Constant: '<S501>/Constant31'
    //   Constant: '<S501>/Constant32'
    //   Constant: '<S501>/Constant33'
    //   Constant: '<S501>/Constant34'
    //   Constant: '<S501>/Constant35'
    //   Constant: '<S501>/Constant36'
    //   Constant: '<S501>/Constant37'
    //   Constant: '<S501>/Constant38'
    //   Constant: '<S501>/Constant39'
    //   Constant: '<S501>/Constant4'
    //   Constant: '<S501>/Constant40'
    //   Constant: '<S501>/Constant5'
    //   Constant: '<S501>/Constant7'
    //   Constant: '<S501>/Constant8'
    //   Constant: '<S501>/Constant9'
    //   Constant: '<S6>/waypoint_reached'
    //   DataTypeConversion: '<S501>/Data Type Conversion'
    //   DataTypeConversion: '<S6>/Data Type Conversion1'
    //   Inport: '<Root>/Sensor Data'
    //   SignalConversion generated from: '<S6>/Bus Creator2'
    ctrl->waypoint_reached = false;
    ctrl->mode = sensor.inceptor.mode0;
    ctrl->sbus[0] = 0.0F;
    ctrl->sbus[1] = 0.0F;
    ctrl->sbus[2] = 0.0F;
    ctrl->sbus[3] = 0.0F;
    ctrl->sbus[4] = 0.0F;
    ctrl->sbus[5] = 0.0F;
    ctrl->sbus[6] = 0.0F;
    ctrl->sbus[7] = 0.0F;
    ctrl->sbus[8] = 0.0F;
    ctrl->sbus[9] = 0.0F;
    ctrl->sbus[10] = 0.0F;
    ctrl->sbus[11] = 0.0F;
    ctrl->sbus[12] = 0.0F;
    ctrl->sbus[13] = 0.0F;
    ctrl->sbus[14] = 0.0F;
    ctrl->sbus[15] = 0.0F;
    for (i = 0; i < 8; i++) {
      ctrl->pwm[i] = static_cast<real32_T>(rtb_Switch[i]);
    }

    std::memset(&ctrl->aux[0], 0, 24U * sizeof(real32_T));

    // End of Outport: '<Root>/Control Data'
  }

  // Model initialize function
  void Autocode::initialize()
  {
    // Registration code

    // initialize non-finites
    rt_InitInfAndNaN(sizeof(real_T));
  }

  // Constructor
  Autocode::Autocode() :
    rtDW()
  {
    // Currently there is no constructor body generated.
  }

  // Destructor
  Autocode::~Autocode()
  {
    // Currently there is no destructor body generated.
  }
}

//
// File trailer for generated code.
//
// [EOF]
//
